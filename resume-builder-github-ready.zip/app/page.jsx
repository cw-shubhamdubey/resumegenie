import { SplashScreen } from "@/components/splash-screen"

function HomePage() {
  return (
    <main>
      <SplashScreen />
    </main>
  )
}

